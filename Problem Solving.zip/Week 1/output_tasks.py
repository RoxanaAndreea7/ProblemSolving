print("Welcome to COM411!")
print("In week 1 we will learn...")
print()
print("...How to use Git and GitHub")
print("...How to output to the screen")
print("...How to get user input")
print()
print("I hope you are enjoying the lesson thus far!")


print("""
Welcome to COM411!
In week 1 we will learn...

...How to use Git and GitHub
...How to output to the screen
...How to get user input

I hope you are enjoying the lesson thus far!
""")