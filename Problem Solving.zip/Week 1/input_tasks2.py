
print("Please enter eye character")
eye = input()

print("##########")
print(f"#  {eye}  {eye}   #")
print("#  ----  #")
print("##########")