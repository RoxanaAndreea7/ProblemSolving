# Display escape characters
print("\n Displays a new line")
print("\t Displays a tab space")
print("\\ Displays a back slash")
print("\" Displays a double quote")
print("\' Displays a single quote")

# Display a message
print(" \n\t\t\"I am programming!\" ")
