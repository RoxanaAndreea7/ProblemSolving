
print("What is your name?")

name = input()

print(f"Nice to meet you {name}")