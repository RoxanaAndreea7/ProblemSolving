print("Please enter a phrase")
user_phrase = input()
initial_lenght = 0
while initial_lenght < len(user_phrase):
    print("Hello" , end="")
    initial_lenght += 1