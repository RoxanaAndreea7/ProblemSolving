print("How many mountains should I display?")

display = int(input())

for mountain in range(display):
    print ("""
           __
          /  \\_  
         /^    \\_
        /  ^     \\_
      _/ ^ ^      ^\\_
     /  ^     ^     \\_
     
    """)
print("Done!")