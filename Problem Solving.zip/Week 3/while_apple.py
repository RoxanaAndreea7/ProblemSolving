print("How many apples should I remove")
remove_apple = int(input())
no_of_remove_apples = 0
while no_of_remove_apples < remove_apple:
    print(f"Apple {no_of_remove_apples} removed")
    no_of_remove_apples += 1