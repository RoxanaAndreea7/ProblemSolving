print("Calculating the sum of the first numbers")
num = 1
total = 5

while num<=100:
    total = total + num
    num = num + 1

print(f"Done! the answer is: {total}")